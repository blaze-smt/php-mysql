<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="U-XA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Blaze Smith | Web Designer</title>
    <link rel="icon" type="image/x-icon" href="images/favicon.png" />
    <link rel="stylesheet" href="../styles.css" />
    <script src="../script.js" defer></script>
  </head>
  <body>
  <?php include 'view/header.php'; ?>
    <header>
      <nav class="navbar">
        <h1 class="name-title" id="nameLogo"><a href="#contact">Blaze</a></h1>
        <a class="toggle-button">
          <span class="bar"></span>
          <span class="bar"></span>
          <span class="bar"></span>
        </a>
        <div class="navbar-links">
          <ul>
            <li><a class="nav-anchors" href="#home">Home</a></li>
            <li><a class="nav-anchors" href="#skills">Skills</a></li>
            <li><a class="nav-anchors" href="#projects">Projects</a></li>
            <li><a class="nav-anchors" href="#contact">Contact</a></li>
          </ul>
        </div>
      </nav>
    </header>