/*****************************************
* Create the portfolio database
*****************************************/
DROP DATABASE IF EXISTS portfolio;
CREATE DATABASE portfolio;
USE portfolio;  -- MySQL command

-- create the tables
CREATE TABLE skills (
  skillID       INT(11)        NOT NULL   AUTO_INCREMENT,
  skillName     VARCHAR(255)   NOT NULL,
  PRIMARY KEY (skillID)
);

-- insert data into the database
INSERT INTO skills VALUES
(1, 'HTML'),
(2, 'CSS'),
(3, 'JavaScript'),
(4, 'NodeJS'),
(5, 'ExpressJS'),
(6, 'Bootstrap'),
(7, 'Git'),
(8, 'MySQL'),
(9, 'Photoshop'),
(10, 'Illustrator'),
(11, 'Figma');
-- create the users and grant priveleges to those users
GRANT SELECT, INSERT, DELETE, UPDATE
ON portfolio.*
TO mgs_user@localhost
IDENTIFIED BY PASSWORD 'pa55word';