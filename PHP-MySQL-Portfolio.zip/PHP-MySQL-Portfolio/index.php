<?php
  require_once('model/database.php');

  // get all skills
  $query = 'SELECT * FROM skills
  ORDER BY skillID';
  $statement = $db -> prepare($query);
  $statement -> execute();
  $skills = $statement -> fetchAll();
  $statement -> closeCursor()
?>

<?php include 'views/header.php'; ?>
    <!-- HOME START -->
    <main class="bodyContainer" id="home">
      <article class="homeMain">
        <article class="homeArticle1">
          <p>Hello! I'm <strong>Blaze</strong></p>
        </article>
        <aside class="home-img-container">
          <img
            src="/public/images/homePic.png"
            alt=""
            aria-describedby="home-description"
          />
        </aside>
        <article class="homeArticle2">
          <p id="home-description">
            I currently am obtaining my degree in <br />
            <strong>Web Design</strong> at
            <strong id="ntc-text">Northcentral Technical College</strong>
          </p>
        </article>
        <div class="break"></div>
        <div class="homeButtonContainer">
          <a class="contactBtn" href="#contact">
            <p>Contact Me</p>
          </a>
        </div>
      </article>
    </main>
    <!-- HOME END -->
    <div class="seperatorContainer">
      <section class="seperator" id="skills"><h2>Skills</h2></section>
    </div>
    <!-- SKILLS START -->
    <div class="bodyContainer">
      <main class="skillsMain">
        <?php foreach ($skills as $skill) : ?>
          <figure class="skills">
            <img src="/public/images/skills/<?php echo $skill['skillName']; ?>.svg" alt="<?php echo $skill['skillName']; ?>" />
            <figcaption class="skills-caption"><?php echo $skill['skillName']; ?></figcaption>
          </figure>
        <?php endforeach; ?>
      </main>
    </div>
    <!-- SKILLS END -->
    <div class="seperatorContainer">
      <section class="seperator" id="projects"><h2>Projects</h2></section>
    </div>
    <!-- PROJECTS START -->
    <main class="bodyContainer">
      <article class="projectsMain">
        <aside class="projectsAside">
          <img
            class="projectImgs"
            src="public/gifs/stapledHills.gif"
            alt="Clothing Brands"
            aria-labelledby="brand-label"
            aria-describedby="brand-desc"
          />
          <h1 id="brand-label">INFST + Stapled Hills</h1>
          <a class="completed" href="https://stapledhills.com/" target="_blank">
            <p>Completed</p>
            <svg
              width="25"
              height="25"
              viewBox="0 0 300 300"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M210 128.25V170.5V225C210 241.569 196.569 255 180 255H71C54.4315 255 41 241.569 41 225V116C41 99.4315 54.4315 86 71 86H125.5H167.75"
                stroke="black"
                stroke-width="20"
              />
              <path
                d="M256.007 50C256.007 44.4772 251.53 40 246.007 40H156.007C150.484 40 146.007 44.4772 146.007 50C146.007 55.5228 150.484 60 156.007 60L236.007 60V140C236.007 145.523 240.484 150 246.007 150C251.53 150 256.007 145.523 256.007 140V50ZM181.071 129.078L253.078 57.0711L238.936 42.9289L166.929 114.936L181.071 129.078Z"
                fill="black"
              />
              <circle cx="174" cy="122" r="10" fill="black" />
            </svg>
          </a>
        </aside>
        <aside class="projectsAside">
          <img
            class="projectImgs"
            src="/public/images/2020portfolio.png"
            aria-labelledby="2020-portfolio-label"
            aria-describedby="2020-portfolio-desc"
          />
          <h1 id="2020-portfolio-label">2020 Portfolio</h1>
          <a class="completed">
            <p>Completed</p>
          </a>
        </aside>
        <aside class="projectsAside">
          <img
            class="projectImgs"
            src="/public/images/2022portfolio.png"
            aria-labelledby="2022-portfolio-label"
            aria-describedby="2022-portfolio-desc"
          />
          <h1 id="2022-portfolio-label">2022 Portfolio</h1>
          <a class="inProgress">
            <p>In Progress...</p>
          </a>
        </aside>
        <aside class="projectsAside">
          <img
            class="projectImgs"
            src="public/gifs/generativeFrameworks.gif"
            aria-labelledby="gf-label"
            aria-describedby="gf-desc"
          />
          <h1 id="gf-label">Generative Frameworks</h1>
          <a
            class="inProgress"
            href="https://www.instagram.com/generativeframeworks/"
            target="_blank"
          >
            <p>In Progress...</p>
            <svg
              width="25"
              height="25"
              viewBox="0 0 300 300"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M210 128.25V170.5V225C210 241.569 196.569 255 180 255H71C54.4315 255 41 241.569 41 225V116C41 99.4315 54.4315 86 71 86H125.5H167.75"
                stroke="black"
                stroke-width="20"
              />
              <path
                d="M256.007 50C256.007 44.4772 251.53 40 246.007 40H156.007C150.484 40 146.007 44.4772 146.007 50C146.007 55.5228 150.484 60 156.007 60L236.007 60V140C236.007 145.523 240.484 150 246.007 150C251.53 150 256.007 145.523 256.007 140V50ZM181.071 129.078L253.078 57.0711L238.936 42.9289L166.929 114.936L181.071 129.078Z"
                fill="black"
              />
              <circle cx="174" cy="122" r="10" fill="black" />
            </svg>
          </a>
        </aside>
      </article>
    </main>
    <!-- PROJECTS END -->
    <div class="seperatorContainer">
      <section class="seperator" id="contact"><h2>Contact</h2></section>
    </div>
    <!-- CONTACT START -->
    <article class="bodyContainer">
      <div class="contactContainer">
        <a
          class="contactBtn"
          id="emailBtn"
          href="mailto:blazewaynesmith@gmail.com"
        >
          <h4 id="emailCopy">Email Me</h4>
          <svg
            id="copyButton"
            width="35"
            height="35"
            viewBox="0 0 400 400"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <rect
              x="43"
              y="152"
              width="200"
              height="200"
              rx="30"
              stroke-width="20"
            />
            <path
              d="M265.5 244H331C347.569 244 361 230.569 361 214V74C361 57.4315 347.569 44 331 44H191C174.431 44 161 57.4315 161 74V127.5"
              stroke-width="20"
            />
          </svg>
        </a>
      </div>
    </article>
    <!-- CONTACT END -->
  <?php include 'views/footer.php'; ?>
</html>
